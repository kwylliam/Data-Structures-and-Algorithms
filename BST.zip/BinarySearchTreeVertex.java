public class BinarySearchTreeVertex<E> {    
    public E e;
    public BinarySearchTreeVertex<E> parent;
    public BinarySearchTreeVertex<E> left_child;
    public BinarySearchTreeVertex<E> right_child;

}