public class LinkedListNode <K,V>
{ 
public K key; 
public V v; 
public LinkedListNode<K,V> next; 
}