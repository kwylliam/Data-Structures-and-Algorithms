public class LinkedListNode<E>
{
    public E element;
    public LinkedListNode<E> next;
}