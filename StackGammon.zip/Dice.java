public class Dice{


	public int roll(){

		return (int)(1+Math.random()*6);
	}
}